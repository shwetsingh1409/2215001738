'use client';

import { Card, CardContent, Typography, Grid, CardHeader, Avatar } from '@mui/material';
import { useEffect, useState } from 'react';
import api, { Post, User } from '../services/api';

interface ExtendedPost extends Post {
  user: User;
  commentCount: number;
}

export default function TrendingPosts() {
  const [trendingPosts, setTrendingPosts] = useState<ExtendedPost[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTrendingPosts = async () => {
      try {
        const users = await api.getUsers();
        const allPosts: ExtendedPost[] = [];

        await Promise.all(
          users.map(async (user) => {
            const userPosts = await api.getUserPosts(user.id);
            
            await Promise.all(
              userPosts.map(async (post) => {
                const comments = await api.getPostComments(post.id);
                allPosts.push({
                  ...post,
                  user,
                  commentCount: comments.length,
                });
              })
            );
          })
        );

        // Find the maximum comment count
        const maxComments = Math.max(...allPosts.map(post => post.commentCount));
        
        // Filter posts with maximum comments
        const trending = allPosts
          .filter(post => post.commentCount === maxComments)
          .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

        setTrendingPosts(trending);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching trending posts:', error);
        setLoading(false);
      }
    };

    fetchTrendingPosts();
  }, []);

  if (loading) {
    return <Typography>Loading...</Typography>;
  }

  return (
    <div>
      <Typography variant="h4" component="h1" gutterBottom>
        Trending Posts
      </Typography>
      <Grid container spacing={3}>
        {trendingPosts.map((post) => (
          <Grid component="div" item xs={12} md={6} key={post.id}>
            <Card>
              <CardHeader
                avatar={
                  <Avatar
                    src={`https://api.dicebear.com/7.x/avatars/svg?seed=${post.user.id}`}
                  />
                }
                title={post.user.name}
                subheader={new Date(post.timestamp).toLocaleDateString()}
              />
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  {post.title}
                </Typography>
                <Typography variant="body2" color="text.secondary" paragraph>
                  {post.body}
                </Typography>
                <Typography variant="body2" color="primary">
                  {post.commentCount} comments
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </div>
  );
} 