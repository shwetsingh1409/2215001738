import axios from 'axios';

const BASE_URL = 'http://20.244.56.144/evaluation-service';

export interface User {
  id: number;
  name: string;
  image?: string;
  postCount?: number;
  totalComments?: number;
}

export interface Post {
  id: number;
  userId: number;
  title: string;
  body: string;
  image?: string;
  commentCount?: number;
  timestamp: string;
}

export interface Comment {
  id: number;
  postId: number;
  user: string;
  content: string;
  timestamp: string;
}

const api = {
  // Get all users
  getUsers: async (): Promise<User[]> => {
    const response = await axios.get(`${BASE_URL}/users`);
    return response.data;
  },

  // Get posts for a specific user
  getUserPosts: async (userId: number): Promise<Post[]> => {
    const response = await axios.get(`${BASE_URL}/users/${userId}/posts`);
    return response.data;
  },

  // Get comments for a specific post
  getPostComments: async (postId: number): Promise<Comment[]> => {
    const response = await axios.get(`${BASE_URL}/posts/${postId}/comments`);
    return response.data;
  },
};

export default api; 