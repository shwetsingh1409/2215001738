'use client';

import { useEffect, useState } from 'react';
import {
  Card,
  CardContent,
  Typography,
  Grid,
  CardHeader,
  Avatar,
  CircularProgress,
} from '@mui/material';
import api, { Post, User } from '../services/api';

interface ExtendedPost extends Post {
  user: User;
  commentCount: number;
}

const POLLING_INTERVAL = 10000; // Poll every 10 seconds

export default function Feed() {
  const [posts, setPosts] = useState<ExtendedPost[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchPosts = async () => {
    try {
      const users = await api.getUsers();
      const allPosts: ExtendedPost[] = [];

      await Promise.all(
        users.map(async (user) => {
          const userPosts = await api.getUserPosts(user.id);
          
          await Promise.all(
            userPosts.map(async (post) => {
              const comments = await api.getPostComments(post.id);
              allPosts.push({
                ...post,
                user,
                commentCount: comments.length,
              });
            })
          );
        })
      );

      // Sort posts by timestamp, newest first
      const sortedPosts = allPosts.sort(
        (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      );

      setPosts(sortedPosts);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching posts:', error);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPosts();

    // Set up polling for real-time updates
    const interval = setInterval(fetchPosts, POLLING_INTERVAL);

    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[200px]">
        <CircularProgress />
      </div>
    );
  }

  return (
    <div>
      <Typography variant="h4" component="h1" gutterBottom>
        Feed
      </Typography>
      <Grid container spacing={3}>
        {posts.map((post) => (
          <Grid component="div" item xs={12} key={post.id}>
            <Card>
              <CardHeader
                avatar={
                  <Avatar
                    src={`https://api.dicebear.com/7.x/avatars/svg?seed=${post.user.id}`}
                  />
                }
                title={post.user.name}
                subheader={new Date(post.timestamp).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              />
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  {post.title}
                </Typography>
                <Typography variant="body2" color="text.secondary" paragraph>
                  {post.body}
                </Typography>
                <Typography variant="body2" color="primary">
                  {post.commentCount} comments
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </div>
  );
} 