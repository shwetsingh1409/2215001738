'use client';

import { Card, CardContent, Typography, Avatar, Grid } from '@mui/material';
import { useEffect, useState } from 'react';
import api, { User, Post } from './services/api';

export default function TopUsers() {
  const [topUsers, setTopUsers] = useState<(User & { commentCount: number })[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTopUsers = async () => {
      try {
        const users = await api.getUsers();
        const usersWithComments = await Promise.all(
          users.map(async (user) => {
            const posts = await api.getUserPosts(user.id);
            let totalComments = 0;
            
            await Promise.all(
              posts.map(async (post) => {
                const comments = await api.getPostComments(post.id);
                totalComments += comments.length;
              })
            );

            return {
              ...user,
              commentCount: totalComments,
            };
          })
        );

        const sortedUsers = usersWithComments
          .sort((a, b) => b.commentCount - a.commentCount)
          .slice(0, 5);

        setTopUsers(sortedUsers);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching top users:', error);
        setLoading(false);
      }
    };

    fetchTopUsers();
  }, []);

  if (loading) {
    return <Typography>Loading...</Typography>;
  }

  return (
    <div>
      <Typography variant="h4" component="h1" gutterBottom>
        Top Users
      </Typography>
      <Grid container spacing={3}>
        {topUsers.map((user, index) => (
          <Grid component="div" item xs={12} sm={6} md={4} key={user.id}>
            <Card>
              <CardContent>
                <div className="flex items-center gap-4">
                  <Avatar
                    src={`https://api.dicebear.com/7.x/avatars/svg?seed=${user.id}`}
                    sx={{ width: 56, height: 56 }}
                  />
                  <div>
                    <Typography variant="h6">{user.name}</Typography>
                    <Typography variant="body2" color="text.secondary">
                      Total Comments: {user.commentCount}
                    </Typography>
                    <Typography variant="caption" color="primary">
                      Rank #{index + 1}
                    </Typography>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </div>
  );
}
