'use client';

import { AppBar, Toolbar, Typography, Button, Box } from '@mui/material';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

const Navigation = () => {
  const pathname = usePathname();

  const navItems = [
    { label: 'Top Users', path: '/' },
    { label: 'Trending Posts', path: '/trending' },
    { label: 'Feed', path: '/feed' },
  ];

  return (
    <AppBar position="static" sx={{ mb: 4 }}>
      <Toolbar>
        <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
          Social Analytics
        </Typography>
        <Box>
          {navItems.map((item) => (
            <Link key={item.path} href={item.path} passHref>
              <Button
                color="inherit"
                sx={{
                  textTransform: 'none',
                  fontWeight: pathname === item.path ? 'bold' : 'normal',
                  borderBottom: pathname === item.path ? '2px solid white' : 'none',
                  borderRadius: 0,
                  mx: 1,
                }}
              >
                {item.label}
              </Button>
            </Link>
          ))}
        </Box>
      </Toolbar>
    </AppBar>
  );
};

export default Navigation; 