(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_globals_73c37791.css",
  "static/chunks/node_modules_1de074e8._.js",
  "static/chunks/app_components_Navigation_tsx_4011be47._.js"
],
    source: "dynamic"
});
